﻿using System;
using System.Threading;
using System.Threading.Tasks;

class BalkingObject
{
    private bool _isInitialized = false;
    private readonly object _lock = new object();

    public void Initialize()
    {
        lock (_lock)
        {
            if (_isInitialized)
            {
                Console.WriteLine("Initialization already in progress. $safeprojectname$.");
                return;
            }

            _isInitialized = true;
            Console.WriteLine("Initialization started.");

            // Simulating some work with a delay
            Task.Delay(2000).ContinueWith(t => {
                lock (_lock)
                {
                    _isInitialized = false;
                    Console.WriteLine("Initialization completed.");
                }
            });
        }
    }
}

// Client Code
class Program
{
    static void Main(string[] args)
    {
        BalkingObject obj = new BalkingObject();

        Parallel.Invoke(
            () => obj.Initialize(),
            () => obj.Initialize(),
            () => obj.Initialize()
        );

        Console.ReadLine();
    }
}
