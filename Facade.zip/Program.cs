﻿using System;

// Subsystem classes
class SubsystemA
{
    public string OperationA()
    {
        return "Subsystem A, Method A\n";
    }
}

class SubsystemB
{
    public string OperationB()
    {
        return "Subsystem B, Method B\n";
    }
}

class SubsystemC
{
    public string OperationC()
    {
        return "Subsystem C, Method C\n";
    }
}

// $safeprojectname$
class $safeprojectname$
{
    protected SubsystemA _subsystemA;
    protected SubsystemB _subsystemB;
    protected SubsystemC _subsystemC;

    public $safeprojectname$(SubsystemA subsystemA, SubsystemB subsystemB, SubsystemC subsystemC)
    {
        this._subsystemA = subsystemA;
        this._subsystemB = subsystemB;
        this._subsystemC = subsystemC;
    }

    public string Operation()
    {
        string result = "$safeprojectname$ initializes subsystems:\n";
        result += this._subsystemA.OperationA();
        result += this._subsystemB.OperationB();
        result += this._subsystemC.OperationC();
        result += "$safeprojectname$ orders subsystems to perform the action:\n";
        result += this._subsystemA.OperationA();
        result += this._subsystemB.OperationB();
        result += this._subsystemC.OperationC();
        return result;
    }
}

// Client Code
class Client
{
    public static void ClientCode($safeprojectname$ facade)
    {
        Console.Write(facade.Operation());
    }
}

// Run the program
class Program
{
    static void Main(string[] args)
    {
        SubsystemA subsystemA = new SubsystemA();
        SubsystemB subsystemB = new SubsystemB();
        SubsystemC subsystemC = new SubsystemC();
        $safeprojectname$ facade = new $safeprojectname$(subsystemA, subsystemB, subsystemC);
        Client.ClientCode(facade);
    }
}
