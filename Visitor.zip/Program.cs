﻿using System;
using System.Collections.Generic;

// $safeprojectname$ Interface
interface IVisitor
{
    void VisitConcreteElementA(ConcreteElementA element);
    void VisitConcreteElementB(ConcreteElementB element);
}

// Concrete $safeprojectname$
class ConcreteVisitor1 : IVisitor
{
    public void VisitConcreteElementA(ConcreteElementA element)
    {
        Console.WriteLine(element.ExclusiveMethodOfConcreteElementA() + " + ConcreteVisitor1");
    }

    public void VisitConcreteElementB(ConcreteElementB element)
    {
        Console.WriteLine(element.SpecialMethodOfConcreteElementB() + " + ConcreteVisitor1");
    }
}

// Element Interface
interface IElement
{
    void Accept(IVisitor visitor);
}

// Concrete Elements
class ConcreteElementA : IElement
{
    public void Accept(IVisitor visitor)
    {
        visitor.VisitConcreteElementA(this);
    }

    public string ExclusiveMethodOfConcreteElementA()
    {
        return "A";
    }
}

class ConcreteElementB : IElement
{
    public void Accept(IVisitor visitor)
    {
        visitor.VisitConcreteElementB(this);
    }

    public string SpecialMethodOfConcreteElementB()
    {
        return "B";
    }
}

// Object Structure
class ObjectStructure
{
    private List<IElement> _elements = new List<IElement>();

    public void Attach(IElement element)
    {
        _elements.Add(element);
    }

    public void Detach(IElement element)
    {
        _elements.Remove(element);
    }

    public void Accept(IVisitor visitor)
    {
        foreach (IElement element in _elements)
        {
            element.Accept(visitor);
        }
    }
}

// Client Code
class Program
{
    static void Main(string[] args)
    {
        ObjectStructure structure = new ObjectStructure();
        structure.Attach(new ConcreteElementA());
        structure.Attach(new ConcreteElementB());

        ConcreteVisitor1 visitor1 = new ConcreteVisitor1();

        structure.Accept(visitor1);
    }
}
